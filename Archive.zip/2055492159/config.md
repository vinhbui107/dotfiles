Read the documentation on the [AnkiConnect](https://foosoft.net/projects/anki-connect/) project page for details.
